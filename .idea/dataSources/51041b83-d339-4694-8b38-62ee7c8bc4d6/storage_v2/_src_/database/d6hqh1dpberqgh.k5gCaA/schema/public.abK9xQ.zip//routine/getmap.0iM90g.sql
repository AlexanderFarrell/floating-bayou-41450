create function getmap(mapname character varying) returns SETOF maps
    language plpgsql
as
$$
begin
    return query
    SELECT mapdata, width, height
    FROM maps
    WHERE mapName = maps.name;
end;
$$;

alter function getmap(varchar) owner to uvznwscgvkvxvf;

